import setuptools

setuptools.setup(
    name="Attention", 
    version="0.1",
    author="Mark Rabins",
    description="A small package for Mark",
    url="https://github.com/foxbroadcasting/Attention",
    packages=['Attention']
)
